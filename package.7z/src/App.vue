<template>
  <div id="app">

    <router-view/>

  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
@import '../src/assets/css/style.css';
@import '../src/assets/css/responsive.css';
</style>
